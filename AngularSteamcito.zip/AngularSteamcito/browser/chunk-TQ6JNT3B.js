var t="http://localhost:8080/proyectoSteamcito";export{t as a};
